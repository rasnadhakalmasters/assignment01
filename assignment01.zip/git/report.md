# Report
## Team members:
* \<your name> \<your last name>
* \<your name> \<your last name>
* \<your name> \<your last name>

## Repository Analysis
#### Who modified/developed which part of the system?
| Change message | Author | Date & Hour | Lines changed |
--- | --- | --- | ---
|message| john smith |20.20.2020 20:20| 20 |
#### When was which part completed?
YOUR ANSWERE HERE
#### What are merge commits? Identify them in your repository.
YOUR ANSWERE HERE
#### What is the *commit ID* of the *commit* that introduces the `Customer` abstract class?
YOUR ANSWERE HERE
#### What message did the commit include?
YOUR ANSWERE HERE
#### What are the differences between the last two commits pushed to the remote repository?
YOUR ANSWERE HERE